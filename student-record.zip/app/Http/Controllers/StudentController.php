<?php

namespace App\Http\Controllers;

use App\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index(){
        return view('student.index');
    }

    public function getStudentClass(){ // Get class in dropdown
       $student_class = ['First', 'Second', 'Third']; 
       return response()->json($student_class);
    }

    public function getStudataData(Request $request){ // Student list on parameter request
        $records = Student::where('class', $request->student_class)
                           ->select('student_name', 'class', 'age', 'admission_date')
                           ->get();
        return response()->json($records);                   
    }  
}
