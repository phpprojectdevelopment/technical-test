 @include('includes.header');
 <div class="container">  
      <h3 align="center">Students Records</h3>

      <div ng-app="studentApp" ng-controller="studendCtrl" ng-init="loadStudentClass();">
      	<!-- dropdown for selecting class -->
      	<div class="dropdown-box">
		<label for="male">Select class:&nbsp;</label>
		<select ng-model="student_class" ng-change="loadStudentData(student_class)" style="float:right;">
			<option ng-repeat="student_class in student_class_list" value="@{{student_class}}" ng-init="loadStudentData(student_class)">@{{student_class}}</option>
		</select>
		</div>
		<!-- Student list -->
		<table>
		  <tr ng-repeat="x in student_list">
		    <td></td>
		  </tr>
	  	</table>

	  	<table id="customers">
		  <tr>
		    <th>Student Name</th>
		    <th>Class</th>
		    <th>Age</th>
		    <th>Admission Date</th>
		  </tr>
		  <tr ng-repeat="x in student_list">
		    <td>@{{x.student_name}}</td>
		    <td>@{{x.class}}</td>
		    <td>@{{x.age}}</td>
		    <td>@{{x.admission_date}}</td>
		  </tr>
		  
			</table>
	  </div>	  
 </div>
@include('includes.footer');