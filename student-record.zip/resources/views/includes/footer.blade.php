<footer>
<p>Supported by Ovocom Sofware Pvt Ltd</p>
</footer>  
<script>
var app = angular.module("studentApp",[]);  
app.controller("studendCtrl", function($scope, $http){  	

$scope.loadStudentClass = function(){  
var url="{{url('student-class')}}";
$http.get(url).then(function (response) {
$scope.student_class_list = response.data;
$scope.student_class = response.data[0];
});
} 

$scope.loadStudentData = function(student_class){
var url = "{{url('get-student-data')}}?student_class="+student_class;
$http.get(url).then(function (response) {
$scope.student_list = response.data; 
});
}
});
</script>
</body>
</html>  