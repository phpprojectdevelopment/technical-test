<div class="container">
    <div class="col-sm-offset-2 col-sm-8">
        <div class="alert alert-success" role="alert"><?php echo e($message); ?></div>
    </div>
</div>