<?php
print_r($user->name);